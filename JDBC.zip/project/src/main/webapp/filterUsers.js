var angularjs = angular.module('angularjs', []);
angularjs.controller('ctrl', function($scope, $location) {
	$scope.getUsers = function() {
		System.out.println("Hello");
		var user = $scope.user.valueOf();
		if (user.equals("Buyer")) {
			$location.path("/Buyer");
		} else if (user.equals("Advisor")) {
			$location.path("/Advisor");
		} else if (user.equals("Seller")) {
			$location.path("/Seller");
		}

	};
});

angularjs.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/Buyer', {
		templateUrl : 'AllProductsAJS.jsp'
	}).when('/Advisor', {
		templateUrl : 'template/errpage.html'
	}).when('/Seller', {
		templateUrl : 'template/login.html'
	})
} ]);