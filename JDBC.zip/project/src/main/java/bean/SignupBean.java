package bean;

import java.sql.Date;

public class SignupBean 
{
	
		private String name,password,mail_id,mobile_number,degree,user;
		public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		private String birthday;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getMail_id() {
			return mail_id;
		}
		public void setMail_id(String mail_id) {
			this.mail_id = mail_id;
		}
		public String getMobile_number() {
			return mobile_number;
		}
		public void setMobile_number(String mobile_number) {
			this.mobile_number = mobile_number;
		}
		public String getDegree() {
			return degree;
		}
		public void setDegree(String degree) {
			this.degree = degree;
		}
		public String getBirthday() {
			return birthday;
		}
		public void setBirthday(String string) {
			this.birthday = string;
		}
}
