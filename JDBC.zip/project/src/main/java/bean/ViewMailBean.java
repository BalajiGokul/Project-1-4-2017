package bean;

public class ViewMailBean 
{
	private String id,subject,message,sent_to,received_from;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSent_to() {
		return sent_to;
	}

	public void setSent_to(String sent_to) {
		this.sent_to = sent_to;
	}

	public String getReceived_from() {
		return received_from;
	}

	public void setReceived_from(String received_from) {
		this.received_from = received_from;
	}
	

}
