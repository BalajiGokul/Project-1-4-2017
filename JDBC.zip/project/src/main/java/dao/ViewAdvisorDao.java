package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DatabaseConnection;
import bean.viewAdvisor;

public class ViewAdvisorDao 
{
	public List<viewAdvisor> getUsers() throws ClassNotFoundException, SQLException
	{
		List<viewAdvisor> advisor = new ArrayList();
		viewAdvisor advisorBean =null;
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		String query = "select * from advisor_details";
		ps = c.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			advisorBean=new viewAdvisor();
			advisorBean.setName(rs.getString(1));
			advisorBean.setEmail(rs.getString(3));
			advisorBean.setMobile_number(rs.getString(4));
			advisorBean.setBirthday(rs.getString(5));
			advisorBean.setDegree(rs.getString(6));
			advisor.add(advisorBean);
		}
		return advisor;
	}

}