package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DatabaseConnection;
import bean.ProductBean;

public class ViewCartDao {
	public List<ProductBean> getCart(String mobile_number) throws ClassNotFoundException, SQLException {
		Connection connection = DatabaseConnection.getDB();
		PreparedStatement preparedstatement = null;
		String query = "select * from cart where mobile_number = ?";
		preparedstatement=connection.prepareStatement(query);
		preparedstatement.setString(1, mobile_number);
		ResultSet resultset = preparedstatement.executeQuery();
		ProductBean productbean = null;
		List<ProductBean> cartList = new ArrayList<ProductBean>(); 
		while(resultset.next())
		{
			productbean = new ProductBean();
			productbean.setCart_id(resultset.getString(1));
			productbean.setProduct_id(resultset.getString(2));
			productbean.setName(resultset.getString(3));
			productbean.setPrice(resultset.getString(4));
			productbean.setQuantity(resultset.getString(5));
			productbean.setDescription(resultset.getString(6));
			productbean.setSeller(resultset.getString(7));
			productbean.setMobile_number(resultset.getString(8));
			cartList.add(productbean);
		}
		return cartList;
	}

}
