package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DatabaseConnection;
import bean.ProductBean;

public class AddToCart {
	public AddToCart(String product_id, String mobile_number) throws ClassNotFoundException, SQLException {
		Connection connection = DatabaseConnection.getDB();
		PreparedStatement preparedstatement = null;
		
		String query = "insert into temp (id) values (next value for cartid)";
		preparedstatement = connection.prepareStatement(query);
		preparedstatement.executeUpdate();
		query = "select * from temp";
		preparedstatement = connection.prepareStatement(query);
		ResultSet rs = preparedstatement.executeQuery();
		String id=null;
		while (rs.next()) {
			id = rs.getString(1);
		} 
		query = "truncate table temp";
		preparedstatement = connection.prepareStatement(query);
		preparedstatement.execute();
		
		query = "select * from products where product_id = ?";
		preparedstatement = connection.prepareStatement(query);
		preparedstatement.setString(1, product_id);
		ResultSet resultset = preparedstatement.executeQuery();
		ProductBean productBean = new ProductBean();
		while (resultset.next()) {
			productBean.setCart_id(id);
			productBean.setProduct_id(resultset.getString(1));
			productBean.setName(resultset.getString(2));
			productBean.setPrice(resultset.getString(3));
			productBean.setQuantity(resultset.getString(4));
			productBean.setDescription(resultset.getString(5));
			productBean.setSeller(resultset.getString(6));
			productBean.setMobile_number(mobile_number);
		}
		query = "insert into cart (cart_id,product_id,name,price,quantity,description,seller,mobile_number) values (?,?,?,?,?,?,?,?)";
		preparedstatement = connection.prepareStatement(query);
		preparedstatement.setString(1, productBean.getCart_id());
		preparedstatement.setString(2, productBean.getProduct_id());
		preparedstatement.setString(3, productBean.getName());
		preparedstatement.setString(4, productBean.getPrice());
		preparedstatement.setString(5, productBean.getQuantity());
		preparedstatement.setString(6, productBean.getDescription());
		preparedstatement.setString(7, productBean.getSeller());
		preparedstatement.setString(8, productBean.getMobile_number());
		preparedstatement.execute();
	}

}
