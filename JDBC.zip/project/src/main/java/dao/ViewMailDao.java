package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DatabaseConnection;
import bean.ViewMailBean;

public class ViewMailDao 
{
	public List<ViewMailBean> getMails(String action,String mobile_number) throws ClassNotFoundException, SQLException
	{
		List<ViewMailBean> mails = new ArrayList<ViewMailBean>();
		ViewMailBean mailBean =null;
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		String query = "";
		if (action.equals("sent")) {
			query = "select * from sentmail where sender = ?";
		}
		else if (action.equals("received")) {
			query = "select * from receivedmail where receiver=?";
		}
		
		ps = c.prepareStatement(query);
		ps.setString(1, mobile_number);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			mailBean=new ViewMailBean();
			mailBean.setId(rs.getString(1));
			mailBean.setSubject(rs.getString(4));
			mailBean.setMessage(rs.getString(5));
			mailBean.setSent_to(rs.getString(3));
			mailBean.setReceived_from(rs.getString(2));
			mails.add(mailBean);
		}
		return mails;
	}

}
