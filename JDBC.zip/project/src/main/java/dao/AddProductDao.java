package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DatabaseConnection;
import bean.ProductBean;

public class AddProductDao {
	public AddProductDao(ProductBean productbean) throws ClassNotFoundException, SQLException {
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		String id = "";
		String query = "insert into temp (id) values (next value for product_id)";
		ps = c.prepareStatement(query);
		ps.executeUpdate();
		query = "select * from temp";
		ps = c.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			id = rs.getString(1);
		}
		query = "truncate table temp";
		ps = c.prepareStatement(query);
		ps.execute();
		query = "insert into products (product_id,name,price,quantity,description,seller,mobile_number) values (?,?,?,?,?,?,?)";
		ps = c.prepareStatement(query);
		ps.setString(1, id);
		ps.setString(2, productbean.getName());
		ps.setString(3, productbean.getPrice());
		ps.setString(4, productbean.getQuantity());
		ps.setString(5, productbean.getDescription());
		ps.setString(6, productbean.getSeller());
		ps.setString(7, productbean.getMobile_number());
		ps.execute();
	}

}
