package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DatabaseConnection;
import bean.viewUser;

public class ViewUserDao 
{
	public List<viewUser> getUsers(String userType) throws ClassNotFoundException, SQLException
	{
		List<viewUser> users = new ArrayList();
		viewUser userBean =null;
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		String query = "";
		if (userType.equals("Buyer")) {
			query = "select name,email_id,mobile_number,birthday from buyer_details";
		}
		if (userType.equals("Advisor")) {
			query = "select name,email_id,mobile_number,birthday,degree from advisor_details";
		}
		if (userType.equals("Seller")) {
			query = "select name,email_id,mobile_number,birthday from seller_details";
		}
		ps = c.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			userBean=new viewUser();
			userBean.setName(rs.getString(1));
			userBean.setEmail(rs.getString(2));
			userBean.setMobile_number(rs.getString(3));
			userBean.setBirthday(rs.getString(4));
			if(userType.equals("Advisor"))
			{
				userBean.setDegree(rs.getString(5));
			}
			users.add(userBean);
		}
		return users;
	}

}
