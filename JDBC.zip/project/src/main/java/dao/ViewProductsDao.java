package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import util.DatabaseConnection;
import bean.ProductBean;

public class ViewProductsDao {
	final static Logger logger = Logger.getLogger(ViewProductsDao.class);

	public List<ProductBean> getProductsDao(String mobile_number)
			throws ClassNotFoundException, SQLException {
		ProductBean productbean = null;
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		List<ProductBean> products = new ArrayList<ProductBean>();
		String query = "";
		if (mobile_number.equals("all")) {
			query = "select * from products";
			ps = c.prepareStatement(query);
		} else {
			query = "select * from products where mobile_number=?";
			ps = c.prepareStatement(query);
			ps.setString(1, mobile_number);
		}

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			productbean = new ProductBean();
			productbean.setProduct_id(rs.getString(1));
			productbean.setName(rs.getString(2));
			productbean.setPrice(rs.getString(3));
			productbean.setQuantity(rs.getString(4));
			productbean.setDescription(rs.getString(5));
			productbean.setSeller(rs.getString(6));
			productbean.setMobile_number(rs.getString(7));
			products.add(productbean);
		}
		logger.info("logger in product dao");
		return products;
	}

	public List<ProductBean> getProductsDao() throws ClassNotFoundException,
			SQLException {
		ProductBean productbean = null;
		Connection c = DatabaseConnection.getDB();
		PreparedStatement ps = null;
		List<ProductBean> products = new ArrayList<ProductBean>();
		String query = "";
		query = "select * from products";
		ps = c.prepareStatement(query);

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			productbean = new ProductBean();
			productbean.setName(rs.getString(2));
			productbean.setPrice(rs.getString(3));
			productbean.setQuantity(rs.getString(4));
			productbean.setDescription(rs.getString(5));
			productbean.setSeller(rs.getString(6));
			productbean.setMobile_number(rs.getString(7));
			products.add(productbean);
		}
		return products;
	}

}
