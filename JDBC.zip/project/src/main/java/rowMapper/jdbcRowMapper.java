package rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bean.viewUser;

public class jdbcRowMapper implements RowMapper<viewUser> {

	@Override
	public viewUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		viewUser viewUserBean = new viewUser();
		viewUserBean.setName(rs.getString(1));
		viewUserBean.setMobile_number(rs.getString(4));
		viewUserBean.setEmail(rs.getString(3));
		viewUserBean.setBirthday(rs.getString(5));
		try{
			viewUserBean.setDegree(rs.getString(6));	
		}
		catch(Exception e)
		{
			viewUserBean.setDegree(null);
		}
		
		return viewUserBean;
	}

}
